"""Structural interface implemented by the student's Agent; no base class is required."""

from typing import Protocol

from pilab_support.display import Display
from pilab_support.messages import Message
from pilab_support.results import RunResult


class Agent(Protocol):
    """Interface consumed by the shared CLI, TUI, and batch runner.

    Keep conversation history in messages and invoke display callbacks during
    a run. The UI replaces display; batch snapshots messages after each run.
    Implement this structure directly; inheritance is not required.

    An Agent may also expose a slash_commands mapping of command names to help
    text. The TUI forwards matching input unchanged to run().
    """

    messages: list[Message]
    display: Display

    def run(self, prompt: str) -> RunResult:
        """Process a prompt synchronously and return this run's outcome."""
        ...

    def clear(self) -> None:
        """Clear retained conversation state for the interactive /clear command."""
        ...

    def compact(self) -> str:
        """Compact retained history and return a user-facing status message."""
        ...
