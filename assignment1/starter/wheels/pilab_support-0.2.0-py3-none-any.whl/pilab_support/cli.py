"""Shared provider options and interactive, print, and JSONL runners."""

from __future__ import annotations

import argparse
import os
from collections.abc import Callable
from pathlib import Path

from rich.console import Console

from pilab_support.batch import run_batch
from pilab_support.contracts import Agent
from pilab_support.tasks import close_agent
from pilab_support.ui import ConsoleDisplay, render_run_result, run_tui


def create_parser(*, description: str, version: str) -> argparse.ArgumentParser:
    """Create common options; downstream code adds its own feature options/subcommands."""
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("-p", "--print", dest="prompt", help="Run one prompt without the TUI")
    parser.add_argument("--model", default=os.getenv("PILAB_MODEL", "openai/gpt-5-mini"))
    parser.add_argument("--api-key", default=os.getenv("PILAB_API_KEY") or os.getenv("ROUTER_API_KEY"))
    parser.add_argument("--api-base", default=os.getenv("PILAB_API_BASE"))
    parser.add_argument(
        "--provider",
        default=os.getenv("PILAB_PROVIDER"),
        help="LiteLLM provider; a custom API base with a bare model name defaults to openai",
    )
    parser.add_argument("--cwd", type=Path, default=Path.cwd(), help="Workspace available to tools")
    parser.add_argument("--version", action="version", version=f"%(prog)s {version}")
    return parser


def add_batch_command(commands: argparse._SubParsersAction) -> None:
    parser = commands.add_parser("batch", help="Run independent tasks from a JSONL file")
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)


def run_cli(arguments: argparse.Namespace, agent_factory: Callable[[Path], Agent]) -> int:
    """The factory constructs a fresh downstream Agent for the supplied workspace."""
    cwd = arguments.cwd.resolve()
    if arguments.command == "batch":
        return run_batch(arguments.input, arguments.output, cwd, agent_factory)
    agent = agent_factory(cwd)
    if arguments.prompt:
        return run_print_mode(agent, arguments.prompt)
    run_tui(agent, cwd / ".pilab")
    return 0


def run_print_mode(agent: Agent, prompt: str) -> int:
    console = Console()
    previous_display = agent.display
    agent.display = ConsoleDisplay(console)
    try:
        result = agent.run(prompt)
    finally:
        agent.display = previous_display
        close_agent(agent)
    render_run_result(result, console)
    return 0 if result.status == "complete" else 1 if result.status == "error" else 2
