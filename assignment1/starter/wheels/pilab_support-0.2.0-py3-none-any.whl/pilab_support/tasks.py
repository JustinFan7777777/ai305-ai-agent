"""Background execution behind a small synchronous task interface."""

from collections.abc import Callable
from concurrent.futures import CancelledError, Future, ThreadPoolExecutor, wait
from dataclasses import dataclass
from threading import Lock
from typing import Literal
from uuid import uuid4

from pilab_support.results import RunResult


def close_agent(agent: object) -> None:
    """Close agents that own resources without requiring a hook on early stages."""
    close = getattr(agent, "close", None)
    if callable(close):
        close()


@dataclass(frozen=True, slots=True)
class TaskSnapshot:
    task_id: str
    status: Literal["running", "done", "error", "cancelled"]
    result: RunResult | None = None
    error: str | None = None


class BackgroundTasks:
    """Keep task handles and results; each submitted job owns its Agent state."""

    def __init__(self, max_workers: int = 4) -> None:
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        self._tasks: dict[str, Future[RunResult]] = {}
        self._lock = Lock()
        self._closed = False

    def start(self, job: Callable[[], RunResult]) -> str:
        """Schedule work and return an ID without waiting for its result."""
        with self._lock:
            if self._closed:
                raise RuntimeError("Background tasks are closed")
            task_id = f"task-{uuid4().hex}"
            self._tasks[task_id] = self._executor.submit(job)
        return task_id

    def result(self, task_id: str, timeout: float = 0) -> TaskSnapshot:
        """Wait at most timeout seconds; a timeout never stops the worker.

        A returned RunResult means done, even when its Agent status is error.
        Only an exception escaping the job becomes a task-level error.
        """
        if timeout < 0:
            raise ValueError("timeout must be non-negative")
        with self._lock:
            if task_id not in self._tasks:
                raise ValueError(f"Unknown or expired task: {task_id}")
            future = self._tasks[task_id]
        if not future.done():
            wait((future,), timeout=timeout)
        if not future.done():
            return TaskSnapshot(task_id, "running")
        try:
            return TaskSnapshot(task_id, "done", result=future.result())
        except CancelledError:
            return TaskSnapshot(task_id, "cancelled")
        except Exception as error:
            return TaskSnapshot(task_id, "error", error=f"{type(error).__name__}: {error}")

    def close(self) -> None:
        """Reject new jobs, cancel queued jobs, and wait for running jobs.

        Running threads cannot be forcibly cancelled. Results remain readable
        after close; jobs must finish before shutdown can return.
        """
        with self._lock:
            self._closed = True
        self._executor.shutdown(wait=True, cancel_futures=True)
