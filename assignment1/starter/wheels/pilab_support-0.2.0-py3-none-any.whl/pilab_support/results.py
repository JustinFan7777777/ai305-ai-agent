"""The result of one synchronous Agent run."""

from typing import Literal

from pilab_support.messages import StrictModel


class RunResult(StrictModel):
    """Outcome of one run, not the whole retained conversation.

    'complete' means normal termination, not a correct answer. The Agent
    supplies model_calls and tool_calls; support does not measure tokens,
    cost, or child/reviewer calls automatically. Other statuses indicate a
    turn limit, repeated-call stop, or failure; error holds failure details.
    """

    answer: str = ""
    status: Literal["complete", "max_turns", "repeated_call", "error"] = "complete"
    model_calls: int = 0
    tool_calls: int = 0
    error: str | None = None
