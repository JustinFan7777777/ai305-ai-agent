"""LiteLLM adapter and OpenAI Chat Completions message conversion."""

from __future__ import annotations

import json
import os
from collections.abc import Iterator, Mapping, Sequence
from dataclasses import dataclass
from importlib import import_module
from typing import Any

from pilab_support.events import LLMDone, LLMTextDelta, ModelStreamEvent
from pilab_support.llm.base import ModelBackend
from pilab_support.messages import (
    AssistantMessage,
    Message,
    ToolCall,
    ToolMessage,
    UserMessage,
)


@dataclass(slots=True)
class _ToolCallBuffer:
    call_id: str = ""
    name: str = ""
    arguments: str = ""


class LiteLLMBackend(ModelBackend):
    """Use LiteLLM as the provider and wire-protocol compatibility layer."""

    def __init__(
        self,
        model: str,
        *,
        api_key: str | None = None,
        api_base: str | None = None,
        provider: str | None = None,
        max_tokens: int | None = None,
    ) -> None:
        """Configure transport without making a request.

        api_base is the API base, not a /chat/completions endpoint.
        provider is passed as custom_llm_provider. If omitted, a bare model
        name plus api_base selects 'openai'; otherwise LiteLLM infers it.
        The model name is unchanged. PILAB_* variables are read by the CLI,
        not this constructor; pass configuration explicitly from the factory.
        """
        self.model = model
        self.api_key = api_key
        self.api_base = api_base
        self.provider = provider or ("openai" if api_base and "/" not in model else None)
        self.max_tokens = max_tokens

    def complete(
        self,
        messages: Sequence[Message],
        tools: Sequence[dict[str, object]],
        system_prompt: str,
    ) -> AssistantMessage:
        """Consume stream synchronously and return its assembled message."""
        for event in self.stream(messages, tools, system_prompt):
            if isinstance(event, LLMDone):
                return event.message
        raise RuntimeError("Model backend ended without a complete response")

    def stream(
        self,
        messages: Sequence[Message],
        tools: Sequence[dict[str, object]],
        system_prompt: str,
    ) -> Iterator[ModelStreamEvent]:
        """Yield LLMTextDelta events, followed by one LLMDone response.

        Requests streaming and automatic tool choice when tools are supplied.
        Tool fragments are joined by index, then their JSON is parsed locally.
        Missing IDs fall back to tool-{index}, not unique across turns; the
        Agent must detect duplicate IDs. Schemas do not guarantee valid model
        output. Events describe transport, not Agent lifecycle transitions.
        """
        request: dict[str, Any] = {
            "model": self.model,
            "messages": to_chat_completion_messages(messages, system_prompt),
            "stream": True,
        }
        if tools:
            request["tools"] = list(tools)
            request["tool_choice"] = "auto"
        if self.api_key:
            request["api_key"] = self.api_key
        if self.api_base:
            request["api_base"] = self.api_base
        if self.provider:
            request["custom_llm_provider"] = self.provider
        if self.max_tokens:
            request["max_tokens"] = self.max_tokens

        response = _litellm_completion(**request)
        text_parts: list[str] = []
        tool_buffers: dict[int, _ToolCallBuffer] = {}
        finish_reason = "stop"

        for chunk in response:
            choices = _value(chunk, "choices", [])
            if not choices:
                continue
            choice = choices[0]
            finish_reason = _value(choice, "finish_reason", None) or finish_reason
            delta = _value(choice, "delta", {})
            text = _value(delta, "content", None)
            if text:
                text_parts.append(str(text))
                yield LLMTextDelta(text=str(text))

            for raw_call in _value(delta, "tool_calls", None) or []:
                index = int(_value(raw_call, "index", 0))
                buffer = tool_buffers.setdefault(index, _ToolCallBuffer())
                buffer.call_id += str(_value(raw_call, "id", "") or "")
                function = _value(raw_call, "function", {})
                buffer.name += str(_value(function, "name", "") or "")
                buffer.arguments += str(_value(function, "arguments", "") or "")

        tool_calls = [
            ToolCall(
                id=buffer.call_id or f"tool-{index}",
                name=buffer.name,
                arguments=parse_tool_arguments(buffer.arguments),
            )
            for index, buffer in sorted(tool_buffers.items())
        ]
        yield LLMDone(
            message=AssistantMessage(
                content="".join(text_parts),
                tool_calls=tool_calls,
                finish_reason=finish_reason,
            )
        )


def _litellm_completion(**request: Any) -> Any:
    os.environ.setdefault("LITELLM_LOCAL_MODEL_COST_MAP", "True")
    litellm = import_module("litellm")
    return litellm.completion(**request)


def _value(value: object, key: str, default: Any) -> Any:
    if isinstance(value, Mapping):
        return value.get(key, default)
    return getattr(value, key, default)


def parse_tool_arguments(raw: str) -> dict[str, object]:
    """Parse a JSON object, or return {} for empty input.

    Malformed JSON and non-object values become {'__invalid_json__': raw}.
    Argument names are not repaired; validate against the tool schema later.
    """
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return {"__invalid_json__": raw}
    return parsed if isinstance(parsed, dict) else {"__invalid_json__": raw}


def to_chat_completion_messages(messages: Sequence[Message], system_prompt: str) -> list[dict[str, object]]:
    """Prepend the system prompt and serialize messages for Chat Completions.

    Encode tool arguments as JSON and preserve call/result IDs. Local
    timestamp, finish_reason, and is_error fields are omitted; include error
    details in a tool message's content when the model needs to see them.
    """
    result: list[dict[str, object]] = [{"role": "system", "content": system_prompt}]
    for message in messages:
        if isinstance(message, UserMessage):
            result.append({"role": "user", "content": message.content})
        elif isinstance(message, AssistantMessage):
            payload: dict[str, object] = {
                "role": "assistant",
                "content": message.content or None,
            }
            if message.tool_calls:
                payload["tool_calls"] = [
                    {
                        "id": call.id,
                        "type": "function",
                        "function": {
                            "name": call.name,
                            "arguments": json.dumps(call.arguments),
                        },
                    }
                    for call in message.tool_calls
                ]
            result.append(payload)
        elif isinstance(message, ToolMessage):
            result.append(
                {
                    "role": "tool",
                    "tool_call_id": message.tool_call_id,
                    "name": message.name,
                    "content": message.content,
                }
            )
    return result
