"""Provider-independent model interface used by the agent loop."""

from abc import ABC, abstractmethod
from collections.abc import Sequence

from pilab_support.messages import AssistantMessage, Message


class ModelBackend(ABC):
    """The only interface the agent loop needs from a model provider."""

    @abstractmethod
    def complete(
        self,
        messages: Sequence[Message],
        tools: Sequence[dict[str, object]],
        system_prompt: str,
    ) -> AssistantMessage:
        """Synchronously return an assistant response with assembled arguments.

        Pass the existing conversation, Chat Completions function-tool
        definitions, and a separate system prompt. Each tool definition has
        type='function' and a function object containing name, description,
        and parameters (a JSON Schema object).

        This method does not append messages, execute tools, enforce
        permissions, or manage sessions. Provider exceptions propagate;
        the Agent decides how to report them in its RunResult.
        """
        raise NotImplementedError
