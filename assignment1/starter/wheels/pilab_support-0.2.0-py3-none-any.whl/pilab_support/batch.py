"""JSONL batch interface used by checkpoints and external graders."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from pydantic import Field

from pilab_support.contracts import Agent
from pilab_support.messages import Message, StrictModel
from pilab_support.results import RunResult
from pilab_support.tasks import close_agent


class BatchTask(StrictModel):
    """One task with a nonempty id and prompt, and an optional workspace.

    Relative workspace paths are resolved against the input JSONL directory.
    If omitted, the runner uses default_workspace. The directory must exist.
    """

    id: str = Field(min_length=1)
    prompt: str = Field(min_length=1)
    workspace: str | None = None


class BatchResult(RunResult):
    """RunResult plus task id and a snapshot of all Agent messages.

    The transcript preserves tool calls, results, and is_error, but omits
    timestamps. Correctness must be assessed independently of run status.
    """

    id: str
    transcript: list[dict[str, object]] = Field(default_factory=list)


AgentFactory = Callable[[Path], Agent]


def run_batch(
    input_path: Path,
    output_path: Path,
    default_workspace: Path,
    agent_factory: AgentFactory,
) -> int:
    """Run nonempty JSONL lines sequentially, flushing one result per line.

    Create a fresh Agent through agent_factory(workspace) for each task;
    workspace files are not reset. Close the Agent before taking its history
    snapshot. Overwrite output_path, which must differ from input_path.
    Per-line exceptions become error records; processing continues. Return 1
    if any record has status='error', otherwise 0 (not a correctness score).
    """

    source = input_path.resolve()
    target = output_path.resolve()
    if source == target:
        raise ValueError("Batch input and output must be different files")
    if not source.is_file():
        raise ValueError(f"Batch input is not a file: {source}")

    target.parent.mkdir(parents=True, exist_ok=True)
    error_count = 0
    with source.open(encoding="utf-8") as input_file, target.open("w", encoding="utf-8") as output_file:
        for line_number, raw_line in enumerate(input_file, start=1):
            if not raw_line.strip():
                continue
            result = _run_line(
                raw_line,
                line_number=line_number,
                input_directory=source.parent,
                default_workspace=default_workspace,
                agent_factory=agent_factory,
            )
            if result.status == "error":
                error_count += 1
            output_file.write(result.model_dump_json(exclude_none=True) + "\n")
            output_file.flush()
    return 1 if error_count else 0


def _run_line(
    raw_line: str,
    *,
    line_number: int,
    input_directory: Path,
    default_workspace: Path,
    agent_factory: AgentFactory,
) -> BatchResult:
    task_id = f"line-{line_number}"
    agent: Agent | None = None
    try:
        task = BatchTask.model_validate_json(raw_line)
        task_id = task.id
        workspace = _resolve_workspace(task, input_directory, default_workspace)
        agent = agent_factory(workspace)
        try:
            result = agent.run(task.prompt)
        finally:
            # Do not let one line's children keep writing during the next line.
            close_agent(agent)
        return BatchResult(
            id=task.id,
            **result.model_dump(),
            transcript=_serialize_messages(agent.messages),
        )
    except Exception as exc:
        return BatchResult(
            id=task_id,
            status="error",
            transcript=_serialize_messages(agent.messages) if agent is not None else [],
            error=f"{type(exc).__name__}: {exc}",
        )


def _resolve_workspace(task: BatchTask, input_directory: Path, default_workspace: Path) -> Path:
    workspace = Path(task.workspace) if task.workspace is not None else default_workspace.resolve()
    if not workspace.is_absolute():
        workspace = input_directory / workspace
    workspace = workspace.resolve()
    if not workspace.is_dir():
        raise ValueError(f"Workspace is not a directory: {workspace}")
    return workspace


def _serialize_messages(messages: list[Message]) -> list[dict[str, object]]:
    return [message.model_dump(mode="json", exclude={"timestamp"}) for message in messages]
