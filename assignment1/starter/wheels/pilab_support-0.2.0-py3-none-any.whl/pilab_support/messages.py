"""Conversation types with UTC timestamps and per-instance mutable defaults.

Message is a role-discriminated union. Deserialize with
``MESSAGE_ADAPTER.validate_json(raw)`` or ``validate_python(data)``.
These models do not check transcript ordering or call/result pairing.
The Agent owns those checks and tool-specific argument validation.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Annotated, Literal, TypeAlias

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter


def utc_now() -> datetime:
    return datetime.now(UTC)


class StrictModel(BaseModel):
    """Reject undeclared fields; Pydantic strict type mode is not enabled."""

    model_config = ConfigDict(extra="forbid")


class ToolCall(StrictModel):
    """Requested tool name and arguments, linked to its result by id.

    Any argument dictionary is accepted here. Validate the selected tool's
    schema and check that the tool exists before executing side effects.
    """

    id: str
    name: str
    arguments: dict[str, object] = Field(default_factory=dict)


class UserMessage(StrictModel):
    """User input with a UTC creation timestamp."""

    role: Literal["user"] = "user"
    content: str
    timestamp: datetime = Field(default_factory=utc_now)


class AssistantMessage(StrictModel):
    """Model text and zero or more tool requests from one response."""

    role: Literal["assistant"] = "assistant"
    content: str = ""
    tool_calls: list[ToolCall] = Field(default_factory=list)
    finish_reason: str = "stop"
    timestamp: datetime = Field(default_factory=utc_now)


class ToolMessage(StrictModel):
    """Observation linked to a ToolCall by tool_call_id.

    Set is_error for execution failures, including nonzero command exits.
    Explain failures in content too: is_error is local metadata and is not
    sent to the model as a Chat Completions message field.
    """

    role: Literal["tool"] = "tool"
    tool_call_id: str
    name: str
    content: str
    is_error: bool = False
    timestamp: datetime = Field(default_factory=utc_now)


Message: TypeAlias = Annotated[
    UserMessage | AssistantMessage | ToolMessage,
    Field(discriminator="role"),
]
MESSAGE_ADAPTER = TypeAdapter(Message)
