"""Optional workspace execution helpers; not an Agent or a tool dispatcher."""

from __future__ import annotations

import os
import signal
import subprocess
from abc import ABC, abstractmethod
from contextlib import suppress
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class CommandResult:
    """Combined stdout/stderr and process exit code, including nonzero exits."""

    output: str
    exit_code: int


class Sandbox(ABC):
    """Capabilities exposed to coding tools."""

    def __init__(self, root: Path) -> None:
        """Resolve the workspace root; raise ValueError if it is not a directory."""
        self.root = root.resolve()
        if not self.root.is_dir():
            raise ValueError(f"Sandbox root is not a directory: {self.root}")

    def resolve_path(self, raw_path: str) -> Path:
        """Resolve a path inside root, rejecting escapes including symlinks.

        These checks do not protect against adversarial filesystem races.
        """
        candidate = Path(raw_path)
        if not candidate.is_absolute():
            candidate = self.root / candidate
        resolved = candidate.resolve(strict=False)
        if resolved != self.root and self.root not in resolved.parents:
            raise ValueError(f"Path is outside the sandbox: {raw_path}")
        return resolved

    def read_text(self, raw_path: str) -> str:
        """Read the complete UTF-8 file after checking its workspace path."""
        path = self.resolve_path(raw_path)
        return path.read_text(encoding="utf-8")

    def write_text(self, raw_path: str, content: str) -> None:
        """Replace a UTF-8 file within root, creating parent directories."""
        path = self.resolve_path(raw_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def text_files(
        self,
        *,
        extensions: frozenset[str],
        max_files: int,
        max_bytes: int,
    ) -> list[Path]:
        """Select non-hidden files by extension, per-file size, and total count."""
        files: list[Path] = []
        for path in sorted(self.root.rglob("*")):
            relative = path.relative_to(self.root)
            if any(part.startswith(".") for part in relative.parts):
                continue
            if not path.is_file() or path.suffix.lower() not in extensions:
                continue
            if path.stat().st_size > max_bytes:
                continue
            files.append(path)
            if len(files) >= max_files:
                break
        return files

    @abstractmethod
    def run(self, command: str, timeout: float) -> CommandResult:
        """Run a non-interactive command with a timeout in seconds.

        Return combined stdout/stderr and exit code; nonzero exits do not
        raise. Timeout kills the local process group and raises TimeoutError.
        Other OS errors propagate. Terminal stdin is disabled, but commands
        may use their own pipes or redirections. Output size is not bounded.
        """
        raise NotImplementedError


class LocalSandbox(Sandbox):
    """Run /bin/bash -lc with root as the initial working directory.

    Only ENV_ALLOWLIST variables are inherited initially; Bash login startup
    files can still change the environment. This is not an OS security
    sandbox: commands can access host paths outside root.
    """

    ENV_ALLOWLIST = ("PATH", "LANG", "LC_ALL", "TERM", "TMPDIR")

    def run(self, command: str, timeout: float) -> CommandResult:
        """Execute locally using Sandbox.run's output and failure contract."""
        environment = {name: os.environ[name] for name in self.ENV_ALLOWLIST if name in os.environ}
        return _run_process(
            ["/bin/bash", "-lc", command],
            cwd=self.root,
            environment=environment,
            timeout=timeout,
        )


class DockerSandbox(Sandbox):
    """Run Bash in an ephemeral, network-disabled Docker container.

    File tools still use the checked host workspace. Bash receives only that
    workspace as a read-write mount and does not inherit host credentials.
    Requires a running Docker daemon and the selected image. This is not
    per-Agent filesystem isolation. Timeout terminates the local Docker CLI;
    support does not track or remove containers that outlive that client.
    """

    def __init__(
        self,
        root: Path,
        *,
        image: str = "python:3.13-slim",
        memory: str = "512m",
        cpus: float = 1.0,
    ) -> None:
        super().__init__(root)
        self.image = image
        self.memory = memory
        self.cpus = cpus

    def run(self, command: str, timeout: float) -> CommandResult:
        """Execute at /workspace using Sandbox.run's output and failure contract."""
        mount = f"type=bind,source={self.root},target=/workspace"
        return _run_process(
            [
                "docker",
                "run",
                "--rm",
                "--network",
                "none",
                "--memory",
                self.memory,
                "--cpus",
                str(self.cpus),
                "--mount",
                mount,
                "--workdir",
                "/workspace",
                self.image,
                "/bin/bash",
                "-lc",
                command,
            ],
            cwd=self.root,
            environment={"PATH": os.environ.get("PATH", "")},
            timeout=timeout,
        )


def _run_process(
    argv: list[str],
    *,
    cwd: Path,
    environment: dict[str, str],
    timeout: float,
) -> CommandResult:
    process = subprocess.Popen(
        argv,
        cwd=cwd,
        env=environment,
        # The TUI owns terminal input; tools receive input only through their command.
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    try:
        stdout, _ = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        _kill_process_group(process)
        stdout, _ = process.communicate()
        raise TimeoutError(f"Command timed out after {timeout:g} seconds") from None
    return CommandResult(
        output=stdout.decode("utf-8", errors="replace"),
        exit_code=process.returncode or 0,
    )


def _kill_process_group(process: subprocess.Popen[bytes]) -> None:
    if process.returncode is None:
        with suppress(ProcessLookupError):
            os.killpg(process.pid, signal.SIGKILL)
    process.wait()
