"""Workspace capability boundaries; OS sandbox teaching is deferred."""

from pilab_support.execution.sandbox import CommandResult, DockerSandbox, LocalSandbox, Sandbox

__all__ = ["CommandResult", "DockerSandbox", "LocalSandbox", "Sandbox"]
