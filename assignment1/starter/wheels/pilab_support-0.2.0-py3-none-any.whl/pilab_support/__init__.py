"""Upstream infrastructure; the Agent implementation belongs to the downstream project."""

__version__ = "0.2.0"
