"""Transport-level stream fragments used inside the upstream model adapter."""

from typing import Literal, TypeAlias

from pilab_support.messages import AssistantMessage, StrictModel


class LLMTextDelta(StrictModel):
    type: Literal["text_delta"] = "text_delta"
    text: str


class LLMDone(StrictModel):
    type: Literal["done"] = "done"
    message: AssistantMessage


ModelStreamEvent: TypeAlias = LLMTextDelta | LLMDone
