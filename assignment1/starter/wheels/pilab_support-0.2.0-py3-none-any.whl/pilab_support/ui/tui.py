"""A deliberately small prompt-toolkit input loop with Rich rendering."""

from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor, wait
from pathlib import Path
from threading import Event

from prompt_toolkit.history import FileHistory
from prompt_toolkit.patch_stdout import patch_stdout
from prompt_toolkit.shortcuts import PromptSession
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from pilab_support.contracts import Agent
from pilab_support.display import Display
from pilab_support.messages import AssistantMessage, ToolCall, ToolMessage
from pilab_support.results import RunResult
from pilab_support.tasks import close_agent

TOOL_PREVIEW_LINES = 12
TOOL_PREVIEW_CHARS = 2_000
ARGUMENT_PREVIEW_CHARS = 400

HELP = """Commands
  /help      Show this help
  /compact   Queue conversation compaction
  /clear     Queue transcript clearing
  /quit      Cancel queued input and wait for the current run
"""


def run_tui(
    agent: Agent,
    state_dir: Path,
    console: Console | None = None,
) -> None:
    console = console or Console()
    previous_display = agent.display
    agent.display = ConsoleDisplay(console)
    state_dir.mkdir(parents=True, exist_ok=True)
    prompt_session: PromptSession[str] = PromptSession(
        history=FileHistory(str(state_dir / "history")),
    )
    executor = ThreadPoolExecutor(max_workers=1)
    stopping = Event()
    pending = []

    def execute(text: str) -> None:
        if stopping.is_set():
            return
        try:
            if text == "/clear":
                agent.clear()
                console.print("[dim]Transcript cleared.[/dim]")
            elif text == "/compact":
                console.print("[dim]Compacting conversation...[/dim]")
                result = agent.compact()
                console.print(Text(result, style="dim"))
            else:
                render_run_result(agent.run(text), console)
        except Exception as error:
            render_run_result(RunResult(status="error", error=f"{type(error).__name__}: {error}"), console)

    try:
        with patch_stdout(raw=True):
            try:
                console.print(
                    Panel(
                        "PiLab\nType /help for commands. Input is queued while the Agent runs.",
                        border_style="cyan",
                    )
                )
                while True:
                    try:
                        text = prompt_session.prompt("you> ").strip()
                    except (EOFError, KeyboardInterrupt):
                        console.print()
                        break
                    if not text:
                        continue
                    if text in {"/quit", "/exit"}:
                        break
                    if text == "/help":
                        console.print(HELP)
                        continue
                    if text.startswith("/") and text not in {"/clear", "/compact"}:
                        console.print(Text(f"Unknown command: {text}", style="yellow"))
                        continue
                    pending = [future for future in pending if not future.done()]
                    if pending:
                        console.print("[dim]Queued.[/dim]")
                    pending.append(executor.submit(execute, text))
            finally:
                stopping.set()
                for future in pending:
                    future.cancel()
                if any(not future.done() for future in pending):
                    console.print("[dim]Waiting for the current run; queued input was cancelled.[/dim]")
                while any(not future.done() for future in pending):
                    try:
                        wait(pending)
                    except KeyboardInterrupt:
                        console.print("[dim]Still waiting; a running thread cannot be cancelled.[/dim]")
                executor.shutdown(wait=True, cancel_futures=True)
                try:
                    if callable(getattr(agent, "close", None)):
                        console.print("[dim]Closing background tasks...[/dim]")
                    close_agent(agent)
                except Exception as error:
                    render_run_result(
                        RunResult(status="error", error=f"{type(error).__name__}: {error}"), console
                    )
    finally:
        agent.display = previous_display


def render_message(title: str, content: str, console: Console) -> None:
    """Render one conversation turn with a stable visual boundary."""
    style = "yellow" if title.endswith("tool use") else "cyan"
    console.print(Panel(Text(content), title=title, title_align="left", border_style=style, padding=(0, 1)))


def format_preview(
    content: str,
    *,
    max_lines: int = TOOL_PREVIEW_LINES,
    max_chars: int = TOOL_PREVIEW_CHARS,
) -> str:
    """Return a bounded head/tail preview and state what was omitted.

    This only clips presentation, not stored messages or model context.
    Tools must bound their own output separately.
    """
    if not content:
        return "(no output)"
    lines = content.splitlines()
    hidden_lines = max(0, len(lines) - max_lines)
    if hidden_lines:
        head_count = max(1, max_lines - 3)
        tail_count = max(1, max_lines - head_count - 1)
        hidden_lines = len(lines) - head_count - tail_count
        lines = [
            *lines[:head_count],
            f"… [{hidden_lines} lines hidden] …",
            *lines[-tail_count:],
        ]
    preview = "\n".join(lines)
    if len(preview) > max_chars:
        hidden_chars = len(preview) - max_chars
        preview = f"{preview[:max_chars]}\n… [{hidden_chars} more characters hidden]"
    return preview


class ConsoleDisplay(Display):
    """Render ordinary method calls from the Agent, without an event dispatcher."""

    def __init__(self, console: Console) -> None:
        self.console = console

    def assistant(self, message: AssistantMessage) -> None:
        if message.content:
            render_message("Assistant · tool use", message.content, self.console)

    def tool_call(self, call: ToolCall) -> None:
        arguments = json.dumps(call.arguments, ensure_ascii=False, sort_keys=True, default=str)
        self.console.print(
            Panel(
                Text(format_preview(arguments, max_lines=4, max_chars=ARGUMENT_PREVIEW_CHARS)),
                title=f"Tool call · {call.name}",
                title_align="left",
                border_style="yellow",
                padding=(0, 1),
            )
        )

    def tool_result(self, result: ToolMessage) -> None:
        style = "red" if result.is_error else "green"
        status = "error" if result.is_error else "ok"
        self.console.print(
            Panel(
                Text(format_preview(result.content)),
                title=f"Tool result · {result.name} · {status}",
                title_align="left",
                border_style=style,
                padding=(0, 1),
            )
        )


def render_run_result(result: RunResult, console: Console) -> None:
    if result.status == "complete":
        render_message("Assistant · final", result.answer or "(No text response.)", console)
    elif result.status == "error":
        console.print(
            Panel(Text(result.error or "Agent failed."), title="Assistant · error", border_style="red")
        )
    else:
        render_stop_reason(result.status, console)


def render_stop_reason(reason: str, console: Console) -> None:
    if reason == "max_turns":
        console.print("[yellow]Stopped after the configured maximum number of turns.[/yellow]")
    elif reason == "repeated_call":
        console.print("[yellow]Stopped after 3 consecutive identical tool calls.[/yellow]")
