"""Optional presentation calls; the default stays silent for tests and batch runs."""

from pilab_support.messages import AssistantMessage, ToolCall, ToolMessage


class Display:
    """Silent callbacks replaced by ConsoleDisplay in interactive use.

    The Agent invokes these while running. The UI renders the final
    RunResult separately, so the Agent should not print another final reply.
    """

    def assistant(self, message: AssistantMessage) -> None:
        """Present a completed model response, not individual stream tokens."""
        pass

    def tool_call(self, call: ToolCall) -> None:
        """Present a tool request when the Agent dispatches it."""
        pass

    def tool_result(self, result: ToolMessage) -> None:
        """Present the observation returned by a tool."""
        pass
